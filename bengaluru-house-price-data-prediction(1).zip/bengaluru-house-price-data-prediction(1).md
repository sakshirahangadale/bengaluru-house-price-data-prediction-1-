```python
#importing librariesu
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
%matplotlib inline
import matplotlib 
matplotlib.rcParams["figure.figsize"] = (20,10)
```


```python
df1=pd.read_csv('/kaggle/input/bengaluru-house-price-data/Bengaluru_House_Data.csv')
df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>area_type</th>
      <th>availability</th>
      <th>location</th>
      <th>size</th>
      <th>society</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>balcony</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Super built-up  Area</td>
      <td>19-Dec</td>
      <td>Electronic City Phase II</td>
      <td>2 BHK</td>
      <td>Coomee</td>
      <td>1056</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>39.07</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Plot  Area</td>
      <td>Ready To Move</td>
      <td>Chikka Tirupathi</td>
      <td>4 Bedroom</td>
      <td>Theanmp</td>
      <td>2600</td>
      <td>5.0</td>
      <td>3.0</td>
      <td>120.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Built-up  Area</td>
      <td>Ready To Move</td>
      <td>Uttarahalli</td>
      <td>3 BHK</td>
      <td>NaN</td>
      <td>1440</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>62.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Super built-up  Area</td>
      <td>Ready To Move</td>
      <td>Lingadheeranahalli</td>
      <td>3 BHK</td>
      <td>Soiewre</td>
      <td>1521</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>95.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Super built-up  Area</td>
      <td>Ready To Move</td>
      <td>Kothanur</td>
      <td>2 BHK</td>
      <td>NaN</td>
      <td>1200</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>51.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1.shape
```




    (13320, 9)




```python
df1.groupby('area_type')['area_type'].agg("count")
```




    area_type
    Built-up  Area          2418
    Carpet  Area              87
    Plot  Area              2025
    Super built-up  Area    8790
    Name: area_type, dtype: int64




```python
df2=df1.drop(['area_type','society','balcony','availability'],axis='columns')
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>size</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Electronic City Phase II</td>
      <td>2 BHK</td>
      <td>1056</td>
      <td>2.0</td>
      <td>39.07</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Chikka Tirupathi</td>
      <td>4 Bedroom</td>
      <td>2600</td>
      <td>5.0</td>
      <td>120.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Uttarahalli</td>
      <td>3 BHK</td>
      <td>1440</td>
      <td>2.0</td>
      <td>62.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lingadheeranahalli</td>
      <td>3 BHK</td>
      <td>1521</td>
      <td>3.0</td>
      <td>95.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kothanur</td>
      <td>2 BHK</td>
      <td>1200</td>
      <td>2.0</td>
      <td>51.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2.shape
```




    (13320, 5)




```python
#data cleaning
df2.isnull().sum()
```




    location       1
    size          16
    total_sqft     0
    bath          73
    price          0
    dtype: int64




```python
df3=df2.dropna()
df3.isnull().sum()
```




    location      0
    size          0
    total_sqft    0
    bath          0
    price         0
    dtype: int64




```python
df3.shape
```




    (13246, 5)




```python
df3['size'].unique()
```




    array(['2 BHK', '4 Bedroom', '3 BHK', '4 BHK', '6 Bedroom', '3 Bedroom',
           '1 BHK', '1 RK', '1 Bedroom', '8 Bedroom', '2 Bedroom',
           '7 Bedroom', '5 BHK', '7 BHK', '6 BHK', '5 Bedroom', '11 BHK',
           '9 BHK', '9 Bedroom', '27 BHK', '10 Bedroom', '11 Bedroom',
           '10 BHK', '19 BHK', '16 BHK', '43 Bedroom', '14 BHK', '8 BHK',
           '12 Bedroom', '13 BHK', '18 Bedroom'], dtype=object)




```python
#create new column
df3['bhk']=df3['size'].apply(lambda x:int(x.split(" ")[0]))
```

    /opt/conda/lib/python3.7/site-packages/ipykernel_launcher.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      
    


```python
df3.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>size</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Electronic City Phase II</td>
      <td>2 BHK</td>
      <td>1056</td>
      <td>2.0</td>
      <td>39.07</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Chikka Tirupathi</td>
      <td>4 Bedroom</td>
      <td>2600</td>
      <td>5.0</td>
      <td>120.00</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Uttarahalli</td>
      <td>3 BHK</td>
      <td>1440</td>
      <td>2.0</td>
      <td>62.00</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lingadheeranahalli</td>
      <td>3 BHK</td>
      <td>1521</td>
      <td>3.0</td>
      <td>95.00</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kothanur</td>
      <td>2 BHK</td>
      <td>1200</td>
      <td>2.0</td>
      <td>51.00</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
df3['bhk'].unique()
```




    array([ 2,  4,  3,  6,  1,  8,  7,  5, 11,  9, 27, 10, 19, 16, 43, 14, 12,
           13, 18])




```python
df3[df3.bhk>25]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>size</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1718</th>
      <td>2Electronic City Phase II</td>
      <td>27 BHK</td>
      <td>8000</td>
      <td>27.0</td>
      <td>230.0</td>
      <td>27</td>
    </tr>
    <tr>
      <th>4684</th>
      <td>Munnekollal</td>
      <td>43 Bedroom</td>
      <td>2400</td>
      <td>40.0</td>
      <td>660.0</td>
      <td>43</td>
    </tr>
  </tbody>
</table>
</div>




```python
df3.total_sqft.unique()
```




    array(['1056', '2600', '1440', ..., '1133 - 1384', '774', '4689'],
          dtype=object)




```python
def is_float(x):
    try:
        float(x)
    except:
        return False
    return True
```


```python
df3[~df3['total_sqft'].apply(is_float)].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>size</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>30</th>
      <td>Yelahanka</td>
      <td>4 BHK</td>
      <td>2100 - 2850</td>
      <td>4.0</td>
      <td>186.000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>122</th>
      <td>Hebbal</td>
      <td>4 BHK</td>
      <td>3067 - 8156</td>
      <td>4.0</td>
      <td>477.000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>137</th>
      <td>8th Phase JP Nagar</td>
      <td>2 BHK</td>
      <td>1042 - 1105</td>
      <td>2.0</td>
      <td>54.005</td>
      <td>2</td>
    </tr>
    <tr>
      <th>165</th>
      <td>Sarjapur</td>
      <td>2 BHK</td>
      <td>1145 - 1340</td>
      <td>2.0</td>
      <td>43.490</td>
      <td>2</td>
    </tr>
    <tr>
      <th>188</th>
      <td>KR Puram</td>
      <td>2 BHK</td>
      <td>1015 - 1540</td>
      <td>2.0</td>
      <td>56.800</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
def convert_sqft_to_num(x):
    tokens=x.split("-")
    if len(tokens)==2:
        return(float(tokens[0])+float(tokens[1]))/2
    try:
        return float(x)
    except:
        return None
    
```


```python
df4=df3.copy()
df4['total_sqft']=df4['total_sqft'].apply(convert_sqft_to_num)
df4.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>size</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Electronic City Phase II</td>
      <td>2 BHK</td>
      <td>1056.0</td>
      <td>2.0</td>
      <td>39.07</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Chikka Tirupathi</td>
      <td>4 Bedroom</td>
      <td>2600.0</td>
      <td>5.0</td>
      <td>120.00</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Uttarahalli</td>
      <td>3 BHK</td>
      <td>1440.0</td>
      <td>2.0</td>
      <td>62.00</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lingadheeranahalli</td>
      <td>3 BHK</td>
      <td>1521.0</td>
      <td>3.0</td>
      <td>95.00</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kothanur</td>
      <td>2 BHK</td>
      <td>1200.0</td>
      <td>2.0</td>
      <td>51.00</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
#feature engineering 
df5=df4.copy()
```


```python
df5['price_per_sgft']=df5['price']*100000/df5['total_sqft']
df5.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>size</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
      <th>price_per_sgft</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Electronic City Phase II</td>
      <td>2 BHK</td>
      <td>1056.0</td>
      <td>2.0</td>
      <td>39.07</td>
      <td>2</td>
      <td>3699.810606</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Chikka Tirupathi</td>
      <td>4 Bedroom</td>
      <td>2600.0</td>
      <td>5.0</td>
      <td>120.00</td>
      <td>4</td>
      <td>4615.384615</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Uttarahalli</td>
      <td>3 BHK</td>
      <td>1440.0</td>
      <td>2.0</td>
      <td>62.00</td>
      <td>3</td>
      <td>4305.555556</td>
    </tr>
  </tbody>
</table>
</div>




```python
len(df5.location.unique())

```




    1304




```python
#to remove extra spaces 
df5.location=df5.location.apply(lambda x:x.strip())
```


```python
location_stats=df5.groupby('location')['location'].agg('count')
location_stats
```




    location
    1 Annasandrapalya                                  1
    1 Giri Nagar                                       1
    1 Immadihalli                                      1
    1 Ramamurthy Nagar                                 1
    12th cross srinivas nagar banshankari 3rd stage    1
                                                      ..
    t.c palya                                          1
    tc.palya                                           4
    vinayakanagar                                      1
    white field,kadugodi                               1
    whitefiled                                         1
    Name: location, Length: 1293, dtype: int64




```python
location_stats.sort_values(ascending=False)
```




    location
    Whitefield               535
    Sarjapur  Road           392
    Electronic City          304
    Kanakpura Road           266
    Thanisandra              236
                            ... 
    1 Giri Nagar               1
    Kanakapura Road,           1
    Kanakapura main  Road      1
    Karnataka Shabarimala      1
    whitefiled                 1
    Name: location, Length: 1293, dtype: int64




```python
len(location_stats[location_stats<=10])
```




    1052




```python
location_stats_lessthan_10=location_stats[location_stats<=10]
location_stats_lessthan_10
```




    location
    1 Annasandrapalya                                  1
    1 Giri Nagar                                       1
    1 Immadihalli                                      1
    1 Ramamurthy Nagar                                 1
    12th cross srinivas nagar banshankari 3rd stage    1
                                                      ..
    t.c palya                                          1
    tc.palya                                           4
    vinayakanagar                                      1
    white field,kadugodi                               1
    whitefiled                                         1
    Name: location, Length: 1052, dtype: int64




```python
df5.location=df5.location.apply(lambda x:'Other' if x in location_stats_lessthan_10 else x)
```


```python
len(df5.location.unique())
```




    242




```python
df5.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>size</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
      <th>price_per_sgft</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Electronic City Phase II</td>
      <td>2 BHK</td>
      <td>1056.0</td>
      <td>2.0</td>
      <td>39.07</td>
      <td>2</td>
      <td>3699.810606</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Chikka Tirupathi</td>
      <td>4 Bedroom</td>
      <td>2600.0</td>
      <td>5.0</td>
      <td>120.00</td>
      <td>4</td>
      <td>4615.384615</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Uttarahalli</td>
      <td>3 BHK</td>
      <td>1440.0</td>
      <td>2.0</td>
      <td>62.00</td>
      <td>3</td>
      <td>4305.555556</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lingadheeranahalli</td>
      <td>3 BHK</td>
      <td>1521.0</td>
      <td>3.0</td>
      <td>95.00</td>
      <td>3</td>
      <td>6245.890861</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kothanur</td>
      <td>2 BHK</td>
      <td>1200.0</td>
      <td>2.0</td>
      <td>51.00</td>
      <td>2</td>
      <td>4250.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Whitefield</td>
      <td>2 BHK</td>
      <td>1170.0</td>
      <td>2.0</td>
      <td>38.00</td>
      <td>2</td>
      <td>3247.863248</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Old Airport Road</td>
      <td>4 BHK</td>
      <td>2732.0</td>
      <td>4.0</td>
      <td>204.00</td>
      <td>4</td>
      <td>7467.057101</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Rajaji Nagar</td>
      <td>4 BHK</td>
      <td>3300.0</td>
      <td>4.0</td>
      <td>600.00</td>
      <td>4</td>
      <td>18181.818182</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Marathahalli</td>
      <td>3 BHK</td>
      <td>1310.0</td>
      <td>3.0</td>
      <td>63.25</td>
      <td>3</td>
      <td>4828.244275</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Other</td>
      <td>6 Bedroom</td>
      <td>1020.0</td>
      <td>6.0</td>
      <td>370.00</td>
      <td>6</td>
      <td>36274.509804</td>
    </tr>
  </tbody>
</table>
</div>




```python
#outlier detection and removal
#1)outlier removal in sqft
df5[df5.total_sqft/df5.bhk<300].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>size</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
      <th>price_per_sgft</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>9</th>
      <td>Other</td>
      <td>6 Bedroom</td>
      <td>1020.0</td>
      <td>6.0</td>
      <td>370.0</td>
      <td>6</td>
      <td>36274.509804</td>
    </tr>
    <tr>
      <th>45</th>
      <td>HSR Layout</td>
      <td>8 Bedroom</td>
      <td>600.0</td>
      <td>9.0</td>
      <td>200.0</td>
      <td>8</td>
      <td>33333.333333</td>
    </tr>
    <tr>
      <th>58</th>
      <td>Murugeshpalya</td>
      <td>6 Bedroom</td>
      <td>1407.0</td>
      <td>4.0</td>
      <td>150.0</td>
      <td>6</td>
      <td>10660.980810</td>
    </tr>
    <tr>
      <th>68</th>
      <td>Devarachikkanahalli</td>
      <td>8 Bedroom</td>
      <td>1350.0</td>
      <td>7.0</td>
      <td>85.0</td>
      <td>8</td>
      <td>6296.296296</td>
    </tr>
    <tr>
      <th>70</th>
      <td>Other</td>
      <td>3 Bedroom</td>
      <td>500.0</td>
      <td>3.0</td>
      <td>100.0</td>
      <td>3</td>
      <td>20000.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df5.shape
```




    (13246, 7)




```python
 df6=df5[~(df5.total_sqft/df5.bhk<300)] 
 df6.shape 
```




    (12502, 7)




```python
#2)outlier removal in price
df6.price_per_sgft.describe()
```




    count     12456.000000
    mean       6308.502826
    std        4168.127339
    min         267.829813
    25%        4210.526316
    50%        5294.117647
    75%        6916.666667
    max      176470.588235
    Name: price_per_sgft, dtype: float64




```python
def remove_pps_outliers(df):
    df_out=pd.DataFrame()
    for key, subdf in df.groupby('location'):
        m=np.mean(subdf.price_per_sgft)
        st=np.std(subdf.price_per_sgft)
        reduced_df=subdf[(subdf.price_per_sgft>(m-st)) & (subdf.price_per_sgft<=(m+st))]
        df_out=pd.concat([df_out,reduced_df],ignore_index=True)
    return df_out   
```


```python
df7=remove_pps_outliers(df6)
df7.shape
```




    (10241, 7)




```python
def plot_scatter_chart(df,location):
    bhk2 = df[(df.location==location) & (df.bhk==2)]
    bhk3 = df[(df.location==location) & (df.bhk==3)]
    matplotlib.rcParams['figure.figsize'] = (15,10)
    plt.scatter(bhk2.total_sqft,bhk2.price,color='blue',label='2 BHK', s=50)
    plt.scatter(bhk3.total_sqft,bhk3.price,marker='+', color='green',label='3 BHK', s=50)
    plt.xlabel("Total Square Feet Area")
    plt.ylabel("Price (Lakh Indian Rupees)")
    plt.title(location)
    plt.legend()
       
```


```python
plot_scatter_chart(df7,'Rajaji Nagar')
```


    
![png](output_37_0.png)
    



```python
#need to remove 2bhk apartment whose price per sqft is less than price per sqft of 1 bhk apartment
def remove_bhk_outliers(df):
    exclude_indices = np.array([])
    for location, location_df in df.groupby('location'):
        bhk_stats = {}
        for bhk, bhk_df in location_df.groupby('bhk'):
            bhk_stats[bhk] = {
                'mean': np.mean(bhk_df.price_per_sgft),
                'std': np.std(bhk_df.price_per_sgft),
                'count': bhk_df.shape[0]
            }
        for bhk, bhk_df in location_df.groupby('bhk'):
            stats = bhk_stats.get(bhk-1)
            if stats and stats['count']>5:
                exclude_indices = np.append(exclude_indices, bhk_df[bhk_df.price_per_sgft<(stats['mean'])].index.values)
    return df.drop(exclude_indices,axis='index')
df8 = remove_bhk_outliers(df7)

df8.shape

```




    (7329, 7)




```python
plot_scatter_chart(df8,'Rajaji Nagar')
```


    
![png](output_39_0.png)
    



```python
plt.hist(df8.price_per_sgft,rwidth=0.8)
plt.xlabel('price per sqft')
plt.ylabel('count')
```




    Text(0, 0.5, 'count')




    
![png](output_40_1.png)
    



```python
#outlier removal in column bath
df8.bath.unique()
```




    array([ 4.,  3.,  2.,  5.,  8.,  1.,  6.,  7.,  9., 12., 16., 13.])




```python
df8[df8.bath>10]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>size</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
      <th>price_per_sgft</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5277</th>
      <td>Neeladri Nagar</td>
      <td>10 BHK</td>
      <td>4000.0</td>
      <td>12.0</td>
      <td>160.0</td>
      <td>10</td>
      <td>4000.000000</td>
    </tr>
    <tr>
      <th>5925</th>
      <td>Other</td>
      <td>10 BHK</td>
      <td>12000.0</td>
      <td>12.0</td>
      <td>525.0</td>
      <td>10</td>
      <td>4375.000000</td>
    </tr>
    <tr>
      <th>6014</th>
      <td>Other</td>
      <td>16 BHK</td>
      <td>10000.0</td>
      <td>16.0</td>
      <td>550.0</td>
      <td>16</td>
      <td>5500.000000</td>
    </tr>
    <tr>
      <th>6747</th>
      <td>Other</td>
      <td>11 BHK</td>
      <td>6000.0</td>
      <td>12.0</td>
      <td>150.0</td>
      <td>11</td>
      <td>2500.000000</td>
    </tr>
    <tr>
      <th>7078</th>
      <td>Other</td>
      <td>13 BHK</td>
      <td>5425.0</td>
      <td>13.0</td>
      <td>275.0</td>
      <td>13</td>
      <td>5069.124424</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.hist(df8.bath,rwidth=0.8)
plt.xlabel('Number of bathroom')
plt.ylabel('count')
```




    Text(0, 0.5, 'count')




    
![png](output_43_1.png)
    



```python
df8[df8.bath>df8.bhk+2]

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>size</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
      <th>price_per_sgft</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1626</th>
      <td>Chikkabanavar</td>
      <td>4 Bedroom</td>
      <td>2460.0</td>
      <td>7.0</td>
      <td>80.0</td>
      <td>4</td>
      <td>3252.032520</td>
    </tr>
    <tr>
      <th>5238</th>
      <td>Nagasandra</td>
      <td>4 Bedroom</td>
      <td>7000.0</td>
      <td>8.0</td>
      <td>450.0</td>
      <td>4</td>
      <td>6428.571429</td>
    </tr>
    <tr>
      <th>5850</th>
      <td>Other</td>
      <td>6 BHK</td>
      <td>11338.0</td>
      <td>9.0</td>
      <td>1000.0</td>
      <td>6</td>
      <td>8819.897689</td>
    </tr>
    <tr>
      <th>9012</th>
      <td>Thanisandra</td>
      <td>3 BHK</td>
      <td>1806.0</td>
      <td>6.0</td>
      <td>116.0</td>
      <td>3</td>
      <td>6423.034330</td>
    </tr>
  </tbody>
</table>
</div>




```python
df9=df8[df8.bath<df8.bhk+2]
df9.shape
```




    (7251, 7)




```python
#drop unnecessary features
df10 = df9.drop(['size','price_per_sgft'],axis='columns')
df10.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1st Block Jayanagar</td>
      <td>2850.0</td>
      <td>4.0</td>
      <td>428.0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1st Block Jayanagar</td>
      <td>1630.0</td>
      <td>3.0</td>
      <td>194.0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1st Block Jayanagar</td>
      <td>1875.0</td>
      <td>2.0</td>
      <td>235.0</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
#text to numerical data-one hot encoding
dummies=pd.get_dummies(df10.location)
dummies.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>1st Block Jayanagar</th>
      <th>1st Phase JP Nagar</th>
      <th>2nd Phase Judicial Layout</th>
      <th>2nd Stage Nagarbhavi</th>
      <th>5th Block Hbr Layout</th>
      <th>5th Phase JP Nagar</th>
      <th>6th Phase JP Nagar</th>
      <th>7th Phase JP Nagar</th>
      <th>8th Phase JP Nagar</th>
      <th>9th Phase JP Nagar</th>
      <th>...</th>
      <th>Vijayanagar</th>
      <th>Vishveshwarya Layout</th>
      <th>Vishwapriya Layout</th>
      <th>Vittasandra</th>
      <th>Whitefield</th>
      <th>Yelachenahalli</th>
      <th>Yelahanka</th>
      <th>Yelahanka New Town</th>
      <th>Yelenahalli</th>
      <th>Yeshwanthpur</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 242 columns</p>
</div>




```python
df11=pd.concat([df10,dummies.drop('Other',axis='columns')],axis='columns')
```


```python
df12=df11.drop('location',axis='columns')
df12.head(3)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>price</th>
      <th>bhk</th>
      <th>1st Block Jayanagar</th>
      <th>1st Phase JP Nagar</th>
      <th>2nd Phase Judicial Layout</th>
      <th>2nd Stage Nagarbhavi</th>
      <th>5th Block Hbr Layout</th>
      <th>5th Phase JP Nagar</th>
      <th>...</th>
      <th>Vijayanagar</th>
      <th>Vishveshwarya Layout</th>
      <th>Vishwapriya Layout</th>
      <th>Vittasandra</th>
      <th>Whitefield</th>
      <th>Yelachenahalli</th>
      <th>Yelahanka</th>
      <th>Yelahanka New Town</th>
      <th>Yelenahalli</th>
      <th>Yeshwanthpur</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2850.0</td>
      <td>4.0</td>
      <td>428.0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1630.0</td>
      <td>3.0</td>
      <td>194.0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1875.0</td>
      <td>2.0</td>
      <td>235.0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 245 columns</p>
</div>




```python
df12.shape
```




    (7251, 245)




```python
X=df12.drop('price',axis='columns')
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_sqft</th>
      <th>bath</th>
      <th>bhk</th>
      <th>1st Block Jayanagar</th>
      <th>1st Phase JP Nagar</th>
      <th>2nd Phase Judicial Layout</th>
      <th>2nd Stage Nagarbhavi</th>
      <th>5th Block Hbr Layout</th>
      <th>5th Phase JP Nagar</th>
      <th>6th Phase JP Nagar</th>
      <th>...</th>
      <th>Vijayanagar</th>
      <th>Vishveshwarya Layout</th>
      <th>Vishwapriya Layout</th>
      <th>Vittasandra</th>
      <th>Whitefield</th>
      <th>Yelachenahalli</th>
      <th>Yelahanka</th>
      <th>Yelahanka New Town</th>
      <th>Yelenahalli</th>
      <th>Yeshwanthpur</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2850.0</td>
      <td>4.0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1630.0</td>
      <td>3.0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1875.0</td>
      <td>2.0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1200.0</td>
      <td>2.0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1235.0</td>
      <td>2.0</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 244 columns</p>
</div>




```python
y=df12.price
y.head()
```




    0    428.0
    1    194.0
    2    235.0
    3    130.0
    4    148.0
    Name: price, dtype: float64




```python
#train test split
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=10)
```


```python
#model building
from sklearn.linear_model import LinearRegression
lr_clf=LinearRegression()
lr_clf.fit(X_train,y_train)
lr_clf.score(X_test,y_test)
```




    0.869191445217436




```python
#K fold cross validation 
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import cross_val_score

cv = ShuffleSplit(n_splits=5, test_size=0.2, random_state=0)

cross_val_score(LinearRegression(), X, y, cv=cv)
```




    array([0.85430675, 0.84187647, 0.84728412, 0.85171729, 0.87168018])


